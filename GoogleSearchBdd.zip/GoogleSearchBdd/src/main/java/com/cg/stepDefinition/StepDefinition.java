package com.cg.stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	private WebDriver driver;
	private WebElement searchBox;
	
	@Given("^User is on Google Home$")
	public void user_is_on_Google_Home() throws InterruptedException  {
		System.setProperty("webdriver.chrome.driver", "C://Users//bkewlani//Desktop//selenium//chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		Thread.sleep(5000);
		
	  
	}

	@When("^User finds search box$")
	public void user_finds__search_box()  {
		
	   searchBox = driver.findElement(By.xpath("//input[@name='q']"));
	
	}

	@Then("^it enters a search keyword$")
	public void it_enters_a_search_keyword() throws InterruptedException {
		searchBox.sendKeys("Cricket World Cup 2019");
		  searchBox.submit();
		  Thread.sleep(10000);  
		  driver.quit();
	    
	}
	

}
