package com.capstore.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\srgangas\\Desktop\\BDD\\CapStoreProject\\src\\test\\java\\com\\capstore\\feature", glue = "com.capstore.stepDef", plugin = {
		"pretty", "html:target/capstore" }, monochrome = true/*,tags="@smokeTest"*/)
public class TestRunner {

}
