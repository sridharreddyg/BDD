package com.capstore.stepDef;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capstore.pom.Customer;
import cucumber.api.java.After;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CapStoreStedDef {
	WebDriver driver;
	Customer page;
	@Given("^User is on signup Page$")
	public void user_is_on_signup_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C://Users//srgangas//Desktop//BDD//driver//chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(
				"http://localhost:4200/signup");
		driver.manage().window().maximize();
		page = PageFactory.initElements(driver, Customer.class);
	}

	@When("^User leaves firstname empty$")
	public void user_leaves_firstname_empty() throws Throwable {
		 page.setFirstName("");Thread.sleep(500);
		    page.setLastName("reddy");Thread.sleep(500);
		    page.setEmailId("reddy@gmail.com");Thread.sleep(500);
		    page.setMobileNumber("9603005157");Thread.sleep(500);
		    page.setPassword("14911A04k8");Thread.sleep(500);
		    page.setSecurityquestion("What is your middle name?");
		    Thread.sleep(500);
		    page.setAnswer("gangasaram");Thread.sleep(500);
	}

	@When("^Clicks the submit button$")
	public void clicks_the_submit_button() throws Throwable {
		Thread.sleep(3000);
		
		assertFalse(page.getRequest().isEnabled());
	}


	@Then("^Display lastname Alert msg$")
	public void display_lastname_Alert_msg() throws Throwable {
		page.setFirstName("sridhar");Thread.sleep(500);
	    page.setLastName("");Thread.sleep(500);
	    page.setEmailId("reddy@gmail.com");Thread.sleep(500);
	    page.setMobileNumber("9603005157");Thread.sleep(500);
	    page.setPassword("14911A04k8");Thread.sleep(500);
	    page.setSecurityquestion("What is your middle name?");Thread.sleep(500);
	    page.setAnswer("gangasaram");Thread.sleep(500);
	}

	@When("^User leaves email empty$")
	public void user_leaves_email_empty() throws Throwable {
		page.setFirstName("sridhar");Thread.sleep(500);
	    page.setLastName("reddy");Thread.sleep(500);
	    page.setEmailId("");Thread.sleep(500);
	    page.setMobileNumber("9603005157");Thread.sleep(500);
	    page.setPassword("14911A04k8");Thread.sleep(500);
	    page.setSecurityquestion("What is your middle name?");Thread.sleep(500);
	    page.setAnswer("gangasaram");Thread.sleep(500);
	}


	@When("^User leaves mobilenumber empty$")
	public void user_leaves_mobilenumber_empty() throws Throwable {
		page.setFirstName("sridhar");Thread.sleep(500);
	    page.setLastName("reddy");Thread.sleep(500);
	    page.setEmailId("reddy@gmail.com");Thread.sleep(500);
	    page.setMobileNumber("");Thread.sleep(500);
	    page.setPassword("14911A04k8");Thread.sleep(500);
	    page.setSecurityquestion("What is your middle name?");Thread.sleep(500);
	    page.setAnswer("gangasaram");Thread.sleep(500);
	}


	@When("^User leaves password empty$")
	public void user_leaves_password_empty() throws Throwable {
		page.setFirstName("sridhar");Thread.sleep(500);
	    page.setLastName("reddy");Thread.sleep(500);
	    page.setEmailId("reddy@gmail.com");Thread.sleep(500);
	    page.setMobileNumber("9603005157");Thread.sleep(500);
	    page.setPassword("");Thread.sleep(500);
	    page.setSecurityquestion("What is your middle name?");Thread.sleep(500);
	    page.setAnswer("gangasaram");Thread.sleep(500);
	}


	@When("^User leaves securitquestion empty$")
	public void user_leaves_securitquestion_empty() throws Throwable {
		page.setFirstName("sridhar");Thread.sleep(500);
	    page.setLastName("reddy");Thread.sleep(500);
	    page.setEmailId("reddy@gmail.com");Thread.sleep(500);
	    page.setMobileNumber("9603005157");Thread.sleep(500);
	    page.setPassword("14911A04k8");Thread.sleep(500);
	    page.setSecurityquestion("What is your middle name?");Thread.sleep(500);
	    page.setAnswer("gangasaram");Thread.sleep(500);
	}

	

	@When("^User leaves answer empty$")
	public void user_leaves_answer_empty() throws Throwable {
		page.setFirstName("sridhar");Thread.sleep(500);
	    page.setLastName("reddy");Thread.sleep(500);
	    page.setEmailId("reddy@gmail.com");Thread.sleep(500);
	    page.setMobileNumber("9603005157");Thread.sleep(500);
	    page.setPassword("14911A04k8");Thread.sleep(500);
	    page.setSecurityquestion("What is your middle name?");Thread.sleep(500);
	    page.setAnswer("");Thread.sleep(500);
	}

	

	@When("^User enter correct details$")
	public void user_enter_correct_details() throws Throwable {
		page.setFirstName("sridhar");Thread.sleep(500);
	    page.setLastName("reddy");Thread.sleep(500);
	    page.setEmailId("reddy@gmail.com");Thread.sleep(500);
	    page.setMobileNumber("9603005157");Thread.sleep(500);
	    page.setPassword("14911A04k8");Thread.sleep(500);
	    page.setSecurityquestion("What is your middle name?");Thread.sleep(500);
	    page.setAnswer("gangasaram");Thread.sleep(500);
	}

	@When("^Click submit button$")
	public void click_submit_button() throws Throwable {
		Thread.sleep(3000);
		
		assertTrue(page.getRequest().isEnabled());
		page.setRequest();
	}

	@After
	public void closeDriver() throws InterruptedException {
		Thread.sleep(1000);
		driver.close();
	}


}