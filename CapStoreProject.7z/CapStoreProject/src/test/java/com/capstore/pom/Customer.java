package com.capstore.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
public class Customer{

	WebDriver driver;

	@FindBy(how=How.NAME, using="firstName")
	@CacheLookup
	private WebElement firstName;

	@FindBy(how=How.NAME, using="lastName")
	@CacheLookup
	private WebElement lastName;

	@FindBy(how=How.NAME, using="emailId")
	@CacheLookup
	private WebElement emailId;

	@FindBy(how=How.NAME, using="mobileNumber")
	@CacheLookup
	private WebElement mobileNumber;

	@FindBy(how=How.NAME, using="Password")
	@CacheLookup
	private WebElement password;
	
	@FindBy(how=How.NAME, using="securityquestion")
	@CacheLookup
	private WebElement securityquestion;
	@FindBy(how=How.NAME, using="answer")
	@CacheLookup
	private WebElement answer;
	@FindBy(how=How.NAME, using="request")
	@CacheLookup
	private WebElement request;
	public WebElement getRequest() {
		return request;
	}
	public void setRequest() {
		this.request.click();
	}
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public WebElement getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public WebElement getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public WebElement getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}
	public WebElement getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber.sendKeys(mobileNumber);
	}
	public WebElement getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	public WebElement getSecurityquestion() {
		return securityquestion;
	}
	public void setSecurityquestion(String securityquestion) {
		Select dropDown=new Select(this.securityquestion);
		dropDown.selectByVisibleText(securityquestion);
	}
	public WebElement getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer.sendKeys(answer);
	}
	
	
}