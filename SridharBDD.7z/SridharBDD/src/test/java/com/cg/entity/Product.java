package com.cg.entity;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Product {
WebDriver webdriver;
public Product() {
	super();
	// TODO Auto-generated constructor stub
}
public WebDriver getWebdriver() {
	return webdriver;
}
public void setWebdriver(WebDriver webdriver) {
	this.webdriver = webdriver;
}
public WebElement getBrand() {
	return brand;
}
public void setBrand(WebElement brand) {
	this.brand = brand;
}
public WebElement getStorage() {
	return storage;
}
public void setStorage(WebElement storage) {
	this.storage = storage;
}
@FindBy(how = How.ID, using = "selbrand")
@CacheLookup
private WebElement brand;
@FindBy(how = How.ID, using = "selstorage")
@CacheLookup
private WebElement storage;
@FindBy(how = How.ID, using = "btnPayment")
@CacheLookup
private WebElement next;
public WebElement getNext() {
	return next;
}
public void setNext(WebElement next) {
	this.next = next;
}

}
