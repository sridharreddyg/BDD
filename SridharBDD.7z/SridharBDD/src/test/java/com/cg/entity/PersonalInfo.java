package com.cg.entity;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class PersonalInfo {
WebDriver webdriver;
@FindBy(how=How.ID, using="txtFirstName")
@CacheLookup
private WebElement firstname;
@FindBy(how=How.ID, using="txtLastName")
@CacheLookup
private WebElement lastname;
@FindBy(how=How.ID, using="txtEmail")
@CacheLookup
private WebElement email;
@FindBy(how=How.ID, using="txtPhone")
@CacheLookup
private WebElement mobilenumber;
@FindBy(how=How.ID, using="selcity")
@CacheLookup
private WebElement city;
@FindBy(how=How.ID, using="selstate")
@CacheLookup
private WebElement state;
@FindBy(how=How.ID, using="btnPayment")
@CacheLookup
private WebElement next;
@FindBy(how=How.ID, using="txtAddress")
@CacheLookup
private WebElement adderess;
public WebElement getNext() {
	return next;
}
public void setNext(WebElement next) {
	this.next = next;
}
public WebElement getCity() {
	return city;
}
public void setCity(WebElement city) {
	this.city = city;
}
public WebElement getState() {
	return state;
}
public void setState(WebElement state) {
	this.state = state;
}
public PersonalInfo() {
	super();
	// TODO Auto-generated constructor stub
}

public WebDriver getWebdriver() {
	return webdriver;
}
public void setWebdriver(WebDriver webdriver) {
	this.webdriver = webdriver;
}
public WebElement getFirstname() {
	return firstname;
}
public void setFirstname(WebElement firstname) {
	this.firstname = firstname;
}
public WebElement getLastname() {
	return lastname;
}
public void setLastname(WebElement lastname) {
	this.lastname = lastname;
}
public WebElement getEmail() {
	return email;
}
public void setEmail(WebElement email) {
	this.email = email;
}
public WebElement getMobilenumber() {
	return mobilenumber;
}
public void setMobilenumber(WebElement mobilenumber) {
	this.mobilenumber = mobilenumber;
}
public WebElement getAdderess() {
	return adderess;
}
public void setAdderess(WebElement adderess) {
	this.adderess = adderess;
}
}
