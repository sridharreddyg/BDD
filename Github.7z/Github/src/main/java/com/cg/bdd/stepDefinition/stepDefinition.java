package com.cg.bdd.stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * Hello world!
 *
 */
public class stepDefinition 
{
	private WebDriver driver;
	private WebElement searchBox;
	
	@Given("^user is on Github Home Page$")
	public void user_is_on_Github_Home_Page() throws InterruptedException  {
		System.setProperty("webdriver.chrome.driver", "C://Users//srgangas//Desktop//BDD//driver//chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://github.com/");
		driver.findElement(By.xpath("//a[@class='HeaderMenu-link no-underline mr-3']")).click();
		Thread.sleep(5000);
		
	  
	}

	@When("^user enters correct credentials$")
	public void user_enters_correct_credentials()  {
		driver.findElement(By.id("login_field")).sendKeys("sridharreddyg");
		driver.findElement(By.id("password")).sendKeys("14911A04k8#");
	}

	@Then("^login successful$")
	public void login_successful() throws InterruptedException {
		driver.findElement(By.xpath("//input[@name='commit']")).click();
		  Thread.sleep(10000);  	    
	}
	@And("^Go to files$")
	public void go_to_files() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='dashboard-repos-filter-center']")).sendKeys("sri");
	Thread.sleep(5000);
	driver.quit();
	}
}
